# RIVER IMPACT CISADANE — SERVER + GOOGLE SHEETS

Versi server/database dengan menu **Truk Keluar** dan integrasi Google Sheets.

## Jalankan
1. Install Node.js 18+.
2. Buka terminal pada folder ini.
3. Jalankan `npm install`.
4. Jalankan `npm start`.
5. Buka `http://localhost:3000`.

Akun demo:
- admin / admin123
- supervisor / supervisor123
- operator / operator123

## Google Sheets
1. Buat Google Sheet.
2. Extensions → Apps Script.
3. Buka `scripts/google-apps-script.gs`, salin isinya ke Apps Script.
4. Deploy → New deployment → Web app.
5. Execute as: Me.
6. Who has access: Anyone (atau sesuai kebijakan Google Workspace Anda).
7. Salin URL `/exec`.
8. Login sebagai admin → Pengaturan → Google Sheets → tempel URL → Simpan.
9. Dashboard → **Sync Google Sheets**.

Sheet yang dibuat/diisi otomatis:
- sampah_sungai
- sampah_warga
- armada
- muatan_keluar
- audit_logs
- _SYNC_LOG

Database server tetap sumber utama. Google Sheets adalah salinan/referensi untuk rekap dan pelaporan.

## Role
Operator: input/monitoring.
Supervisor: verifikasi dan pengelolaan.
Admin: semua fungsi, pengaturan Google Sheets, dan reset.

## Produksi
Ganti password demo, gunakan HTTPS, isi `.env`, backup folder `data`, dan jangan membuka database langsung ke internet.
